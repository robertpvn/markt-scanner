# Handleiding: jouw automatische markt-scanner in ±5 minuten

Je zet één keer een gratis GitHub-repository op. Daarna scant GitHub **elke
zaterdagochtend (±09:30 NL-tijd)** automatisch alle aandelen van de S&P 500 en
Nasdaq-100 op de weekchart, en krijg je **een e-mail** zodra een aandeel de
200-weeks MA aantikt en/of een weekly RSI onder 30 heeft. Je computer hoeft
hiervoor niet aan te staan.

Wat je nodig hebt: het bestand **markt-scanner.zip** (bij dit bericht geleverd,
eerst uitpakken) en een gratis GitHub-account.

---

## Stap 1 — GitHub-account (overslaan als je er al een hebt)

1. Ga naar **github.com/signup** en maak een gratis account aan met je e-mailadres.

## Stap 2 — Nieuwe repository aanmaken

1. Ga naar **github.com/new**.
2. Repository name: **markt-scanner**
3. Kies **Public** (nodig zodat Claude de resultaten kan meelezen; er staat
   niets persoonlijks in — alleen koersdata en de scan-resultaten).
4. Vink **"Add a README file"** aan.
5. Klik **Create repository**.

## Stap 3 — Bestanden uploaden

1. Pak **markt-scanner.zip** uit op je computer.
2. In je nieuwe repository: klik **Add file → Upload files**.
3. Sleep deze drie bestanden uit de uitgepakte map naar het venster:
   **scanner.py**, **requirements.txt** en **README.md**.
4. Klik onderaan op **Commit changes**.

## Stap 4 — De wekelijkse planning toevoegen

De planning is een "workflow"-bestand dat in een verborgen map hoort; die maak
je zo rechtstreeks op de site aan:

1. Klik **Add file → Create new file**.
2. Typ als bestandsnaam exact (inclusief punten en schuine strepen):

   ```
   .github/workflows/scan.yml
   ```

3. Open in de uitgepakte map het bestand `.github/workflows/scan.yml`
   (staat ook als kopie **scan.yml.txt** in de hoofdmap van de zip, voor het
   geval je verkenner de verborgen `.github`-map niet toont), kopieer de
   volledige inhoud en plak die in het grote tekstvak.
4. Klik **Commit changes**.

## Stap 5 — Eerste scan draait vanzelf

Door stap 4 start de eerste scan direct. Zo volg je hem:

1. Klik op de tab **Actions** (staat er een knop "enable workflows", klik die
   dan eerst aan).
2. Je ziet **"Wekelijkse marktscan"** draaien; na ±5–10 minuten wordt het
   vinkje groen.
3. Op de hoofdpagina van de repository staat daarna **REPORT.md** met het
   volledige rapport, en bij signalen vind je onder de tab **Issues** een
   melding met de lijst.

Handmatig opnieuw scannen kan altijd: **Actions → Wekelijkse marktscan →
Run workflow**.

## Stap 6 — E-mailmeldingen controleren

1. Ga naar **github.com/settings/notifications**.
2. Zorg dat bij **Watching** (Subscriptions) de optie **Email** aangevinkt staat.

Bij elke scan mét signalen wordt een issue aangemaakt in jouw repository en
stuurt GitHub je automatisch een e-mail met de inhoud.

## Stap 7 — Claude koppelen (Cowork-melding erbij)

Stuur mij in de chat de link van je repository, bijvoorbeeld:
`https://github.com/JOUWNAAM/markt-scanner`

Ik stel dan een wekelijkse Cowork-taak in die elke zaterdag rond 12:00 de
resultaten uitleest en je een nette samenvatting plus pushmelding/e-mail vanuit
Claude stuurt.

---

## Instellingen aanpassen (optioneel)

Open `scanner.py` in de repository (potlood-icoon om te bewerken), bovenaan:

| Instelling | Nu | Betekenis |
|---|---|---|
| `MA_TOUCH_PCT` | `0.02` | Marge rond de 200-weeks MA (2%) |
| `RSI_THRESHOLD` | `30.0` | RSI-grens |
| `MA_PERIOD` | `200` | Aantal weken voor het gemiddelde |

Het tijdstip staat in `.github/workflows/scan.yml` (regel met `cron`, in UTC).

## Kosten & goed om te weten

GitHub Actions is gratis voor publieke repositories; deze scan gebruikt maar
een paar minuten per week. Databron is Yahoo Finance (koersen split-adjusted,
zoals op TradingView). De scanner is een technisch hulpmiddel — geen
beleggingsadvies.
