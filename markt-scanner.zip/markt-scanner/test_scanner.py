"""Lokale tests met synthetische data (geen netwerk nodig)."""
import math
import numpy as np
import pandas as pd

import scanner


def make_df(closes, spread=0.01):
    closes = pd.Series(closes, dtype=float)
    idx = pd.date_range("2016-01-04", periods=len(closes), freq="W-FRI")
    return pd.DataFrame({
        "Open": closes.shift(1).fillna(closes.iloc[0]).values,
        "High": (closes * (1 + spread)).values,
        "Low": (closes * (1 - spread)).values,
        "Close": closes.values,
    }, index=idx)


def ref_rsi_wilder(closes, period=14):
    """Onafhankelijke, klassieke Wilder-implementatie (loop, seed = SMA van eerste 14)."""
    deltas = np.diff(closes)
    gains = np.clip(deltas, 0, None)
    losses = -np.clip(deltas, None, 0)
    avg_g = gains[:period].mean()
    avg_l = losses[:period].mean()
    for g, l in zip(gains[period:], losses[period:]):
        avg_g = (avg_g * (period - 1) + g) / period
        avg_l = (avg_l * (period - 1) + l) / period
    if avg_l == 0:
        return 100.0
    rs = avg_g / avg_l
    return 100 - 100 / (1 + rs)


def test_rsi_extremes():
    up = scanner.rsi_wilder(pd.Series(np.linspace(10, 100, 60))).iloc[-1]
    down = scanner.rsi_wilder(pd.Series(np.linspace(100, 10, 60))).iloc[-1]
    assert up == 100.0, up
    assert down < 1e-6, down


def test_rsi_vs_reference():
    rng = np.random.default_rng(42)
    closes = 100 * np.cumprod(1 + rng.normal(0, 0.02, 400))
    ours = scanner.rsi_wilder(pd.Series(closes)).iloc[-1]
    ref = ref_rsi_wilder(closes)
    assert abs(ours - ref) < 0.05, (ours, ref)  # seed-verschil sterft uit


def test_ma_touch_within_2pct():
    closes = np.full(260, 100.0)
    closes[-1] = 101.9  # MA ~= 100 (laatste bar telt licht mee), slot < +2%
    df = make_df(closes, spread=0.001)
    res = scanner.evaluate(df)
    assert res and "200WMA" in res["signals"], res
    assert abs(res["dist_pct"]) <= 2.0, res


def test_ma_touch_by_range():
    closes = np.concatenate([np.full(210, 100.0), np.linspace(100, 96.0, 50)])
    df = make_df(closes, spread=0.05)  # slot >2% onder MA, maar week-high raakt de MA wél
    res = scanner.evaluate(df)
    ma = res["sma200w"] if res else None
    last = df.iloc[-1]
    assert res and "200WMA" in res["signals"], (res, float(last["Low"]), ma, float(last["High"]))


def test_no_signal():
    closes = np.concatenate([np.full(200, 100.0), np.linspace(100, 140, 60)])  # ver boven MA, RSI hoog
    res = scanner.evaluate(make_df(closes, spread=0.001))
    assert res is None, res


def test_rsi_signal_downtrend():
    closes = np.concatenate([np.full(200, 100.0), 100 * 0.97 ** np.arange(60)])  # gestage daling
    res = scanner.evaluate(make_df(closes, spread=0.001))
    assert res and "RSI<30" in res["signals"], res
    assert res["rsi"] < 30


def test_short_history_rsi_only():
    closes = 100 * 0.96 ** np.arange(60)  # 60 weken, geen 200WMA mogelijk
    res = scanner.evaluate(make_df(closes, spread=0.001))
    assert res and res["signals"] == ["RSI<30"] and res["sma200w"] is None, res


def test_too_short_history():
    assert scanner.evaluate(make_df(np.full(20, 100.0))) is None


def test_outputs(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    hits = [
        {"ticker": "AAA", "name": "Alpha", "index": "S&P 500", "signals": ["RSI<30", "200WMA"],
         "close": 50.0, "rsi": 22.5, "sma200w": 51.0, "dist_pct": -1.96, "week_end": "2026-08-14"},
        {"ticker": "BBB", "name": "Beta", "index": "Nasdaq-100", "signals": ["200WMA"],
         "close": 10.0, "rsi": 45.0, "sma200w": 10.1, "dist_pct": -0.99, "week_end": "2026-08-14"},
    ]
    scanner.write_outputs(hits, universe_size=600, scanned=590, warnings=[])
    import json, os
    data = json.load(open("data/signals.json"))
    assert data["signal_count"] == 2
    assert os.path.exists("REPORT.md") and os.path.exists("data/alert.md")
    title = open("data/alert_title.txt").read()
    assert "2 signalen" in title and "1 dubbel" in title, title
    # geen signalen -> alert-bestanden verdwijnen weer
    scanner.write_outputs([], 600, 590, [])
    assert not os.path.exists("data/alert.md") and not os.path.exists("data/alert_title.txt")
    assert "Geen signalen" in open("REPORT.md").read()


def test_download_shape_handling(monkeypatch):
    """Simuleer yf.download met MultiIndex-kolommen."""
    import sys, types
    closes = np.linspace(90, 110, 260)
    single = make_df(closes)
    cols = pd.MultiIndex.from_product([["XXX", "YYY"], single.columns])
    multi = pd.concat({"XXX": single, "YYY": single * 2}, axis=1)
    multi.columns = cols
    fake = types.SimpleNamespace(download=lambda *a, **k: multi)
    monkeypatch.setitem(sys.modules, "yfinance", fake)
    frames = scanner.download_weekly(["XXX", "YYY"])
    assert set(frames) == {"XXX", "YYY"}
    assert len(frames["XXX"]) == 260
