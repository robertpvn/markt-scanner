# 📉 Markt-scanner — S&P 500 + Nasdaq-100 (weekchart)

Deze repository scant elke **zaterdagochtend** automatisch alle aandelen uit de
S&P 500 en de Nasdaq-100 op de **wekelijkse chart** en zoekt naar:

1. **200-weeks SMA aangetikt** — de week-range (high/low) omsluit het
   200-weeks gemiddelde, óf de slotkoers zit er binnen ±2% van;
2. **RSI(14) weekly < 30** — het aandeel is oversold op de weekchart.

## Hoe je een melding krijgt

Als er signalen zijn, maakt de scan automatisch een **GitHub-issue** aan in deze
repository. Omdat je eigenaar bent, krijg je daarvan **een e-mail van GitHub**
(controleer bij twijfel github.com → Settings → Notifications).

## Resultaten

| Bestand | Inhoud |
|---|---|
| `REPORT.md` | Leesbaar rapport van de laatste scan |
| `data/signals.json` | Machineleesbaar resultaat (voor Claude/Cowork) |
| `data/history/` | Archief van alle eerdere scans |

## Handmatig draaien

Tab **Actions** → workflow **“Wekelijkse marktscan”** → knop **Run workflow**.

## Instellingen aanpassen

Bovenin `scanner.py`: `MA_TOUCH_PCT` (nu 2%), `RSI_THRESHOLD` (nu 30),
`MA_PERIOD`, `RSI_PERIOD`. Het schema staat in `.github/workflows/scan.yml`
(cron, in UTC).

---

*Databron: Yahoo Finance. Dit is een technische scanner — geen beleggingsadvies.*
